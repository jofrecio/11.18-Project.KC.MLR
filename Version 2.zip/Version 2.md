
## Final Project Submission

Please fill out:
* Student name: John Ofrecio 
* Student pace: Part-Time 
* Scheduled project review date/time: 
* Instructor name: James Irving 
* Blog post URL:


# Importing Libraries and Packages 


```python
#importing libraries 
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
%matplotlib inline
from math import sqrt

#STATSMODELS
import statsmodels.api as sm
from statsmodels.formula.api import ols

#SCI-KIT LEARN
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
lr = LinearRegression()
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.svm import SVR
import sklearn.metrics as metrics
from sklearn.metrics import mean_squared_error


data = pd.read_csv("kc_house_data.csv")
pd.set_option('display.max_columns' ,0) #displaying all columns 
data.head() #check first 5 rows 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>date</th>
      <th>price</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>sqft_living</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>condition</th>
      <th>grade</th>
      <th>sqft_above</th>
      <th>sqft_basement</th>
      <th>yr_built</th>
      <th>yr_renovated</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_living15</th>
      <th>sqft_lot15</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7129300520</td>
      <td>10/13/2014</td>
      <td>221900.0</td>
      <td>3</td>
      <td>1.00</td>
      <td>1180</td>
      <td>5650</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>3</td>
      <td>7</td>
      <td>1180</td>
      <td>0.0</td>
      <td>1955</td>
      <td>0.0</td>
      <td>98178</td>
      <td>47.5112</td>
      <td>-122.257</td>
      <td>1340</td>
      <td>5650</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6414100192</td>
      <td>12/9/2014</td>
      <td>538000.0</td>
      <td>3</td>
      <td>2.25</td>
      <td>2570</td>
      <td>7242</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>7</td>
      <td>2170</td>
      <td>400.0</td>
      <td>1951</td>
      <td>1991.0</td>
      <td>98125</td>
      <td>47.7210</td>
      <td>-122.319</td>
      <td>1690</td>
      <td>7639</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5631500400</td>
      <td>2/25/2015</td>
      <td>180000.0</td>
      <td>2</td>
      <td>1.00</td>
      <td>770</td>
      <td>10000</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>6</td>
      <td>770</td>
      <td>0.0</td>
      <td>1933</td>
      <td>NaN</td>
      <td>98028</td>
      <td>47.7379</td>
      <td>-122.233</td>
      <td>2720</td>
      <td>8062</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2487200875</td>
      <td>12/9/2014</td>
      <td>604000.0</td>
      <td>4</td>
      <td>3.00</td>
      <td>1960</td>
      <td>5000</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5</td>
      <td>7</td>
      <td>1050</td>
      <td>910.0</td>
      <td>1965</td>
      <td>0.0</td>
      <td>98136</td>
      <td>47.5208</td>
      <td>-122.393</td>
      <td>1360</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1954400510</td>
      <td>2/18/2015</td>
      <td>510000.0</td>
      <td>3</td>
      <td>2.00</td>
      <td>1680</td>
      <td>8080</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>8</td>
      <td>1680</td>
      <td>0.0</td>
      <td>1987</td>
      <td>0.0</td>
      <td>98074</td>
      <td>47.6168</td>
      <td>-122.045</td>
      <td>1800</td>
      <td>7503</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.tail() #check last 5 rows
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>date</th>
      <th>price</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>sqft_living</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>condition</th>
      <th>grade</th>
      <th>sqft_above</th>
      <th>sqft_basement</th>
      <th>yr_built</th>
      <th>yr_renovated</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_living15</th>
      <th>sqft_lot15</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>21592</th>
      <td>263000018</td>
      <td>5/21/2014</td>
      <td>360000.0</td>
      <td>3</td>
      <td>2.50</td>
      <td>1530</td>
      <td>1131</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>8</td>
      <td>1530</td>
      <td>0.0</td>
      <td>2009</td>
      <td>0.0</td>
      <td>98103</td>
      <td>47.6993</td>
      <td>-122.346</td>
      <td>1530</td>
      <td>1509</td>
    </tr>
    <tr>
      <th>21593</th>
      <td>6600060120</td>
      <td>2/23/2015</td>
      <td>400000.0</td>
      <td>4</td>
      <td>2.50</td>
      <td>2310</td>
      <td>5813</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>8</td>
      <td>2310</td>
      <td>0.0</td>
      <td>2014</td>
      <td>0.0</td>
      <td>98146</td>
      <td>47.5107</td>
      <td>-122.362</td>
      <td>1830</td>
      <td>7200</td>
    </tr>
    <tr>
      <th>21594</th>
      <td>1523300141</td>
      <td>6/23/2014</td>
      <td>402101.0</td>
      <td>2</td>
      <td>0.75</td>
      <td>1020</td>
      <td>1350</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>7</td>
      <td>1020</td>
      <td>0.0</td>
      <td>2009</td>
      <td>0.0</td>
      <td>98144</td>
      <td>47.5944</td>
      <td>-122.299</td>
      <td>1020</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>21595</th>
      <td>291310100</td>
      <td>1/16/2015</td>
      <td>400000.0</td>
      <td>3</td>
      <td>2.50</td>
      <td>1600</td>
      <td>2388</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>3</td>
      <td>8</td>
      <td>1600</td>
      <td>0.0</td>
      <td>2004</td>
      <td>0.0</td>
      <td>98027</td>
      <td>47.5345</td>
      <td>-122.069</td>
      <td>1410</td>
      <td>1287</td>
    </tr>
    <tr>
      <th>21596</th>
      <td>1523300157</td>
      <td>10/15/2014</td>
      <td>325000.0</td>
      <td>2</td>
      <td>0.75</td>
      <td>1020</td>
      <td>1076</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>7</td>
      <td>1020</td>
      <td>0.0</td>
      <td>2008</td>
      <td>0.0</td>
      <td>98144</td>
      <td>47.5941</td>
      <td>-122.299</td>
      <td>1020</td>
      <td>1357</td>
    </tr>
  </tbody>
</table>
</div>




```python
column_names = data.columns #list of all column names 
print(column_names) 
```

    Index(['id', 'date', 'price', 'bedrooms', 'bathrooms', 'sqft_living',
           'sqft_lot', 'floors', 'waterfront', 'view', 'condition', 'grade',
           'sqft_above', 'sqft_basement', 'yr_built', 'yr_renovated', 'zipcode',
           'lat', 'long', 'sqft_living15', 'sqft_lot15'],
          dtype='object')


# Column Names and descriptions for Kings County Data Set
* **id** - unique identified for a house
* **dateDate** - house was sold
* **pricePrice** -  is prediction target
* **bedroomsNumber** -  of Bedrooms/House
* **bathroomsNumber** -  of bathrooms/bedrooms
* **sqft_livingsquare** -  footage of the home
* **sqft_lotsquare** -  footage of the lot
* **floorsTotal** -  floors (levels) in house
* **waterfront** - House which has a view to a waterfront
* **view** - Has been viewed
* **condition** - How good the condition is ( Overall )
* **grade** - overall grade given to the housing unit, based on King County grading system
* **sqft_above** - square footage of house apart from basement
* **sqft_basement** - square footage of the basement
* **yr_built** - Built Year
* **yr_renovated** - Year when house was renovated
* **zipcode** - zip
* **lat** - Latitude coordinate
* **long** - Longitude coordinate
* **sqft_living15** - The square footage of interior housing living space for the nearest 15 neighbors
* **sqft_lot15** - The square footage of the land lots of the nearest 15 neighbors



```python
data.info() #housing data information and also to see if there are any missing values 
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 21597 entries, 0 to 21596
    Data columns (total 21 columns):
    id               21597 non-null int64
    date             21597 non-null object
    price            21597 non-null float64
    bedrooms         21597 non-null int64
    bathrooms        21597 non-null float64
    sqft_living      21597 non-null int64
    sqft_lot         21597 non-null int64
    floors           21597 non-null float64
    waterfront       19221 non-null float64
    view             21534 non-null float64
    condition        21597 non-null int64
    grade            21597 non-null int64
    sqft_above       21597 non-null int64
    sqft_basement    21597 non-null object
    yr_built         21597 non-null int64
    yr_renovated     17755 non-null float64
    zipcode          21597 non-null int64
    lat              21597 non-null float64
    long             21597 non-null float64
    sqft_living15    21597 non-null int64
    sqft_lot15       21597 non-null int64
    dtypes: float64(8), int64(11), object(2)
    memory usage: 3.5+ MB


# Observation: 

* There are a total of **21,597** rows and **21** columns
* 3 Columns (**waterfront, view, yr_renovated,**) seems to have some data missing. 
* **waterfront, view, and condition** seem to be categorical 
* **date, sqft_basement** are classified as objects
* **sqft_basement** not all houses have basements and is also marked as an object 

# Getting Rid of Columns that does not really contribute informatin 
   Dropping **ID** and **Date**  


```python
data.drop(['id','date'], axis = 1, inplace =True)# in place TRUE to make sure that the dropped is successful within the dataframe
```


```python
data.head()#columns dropped
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>sqft_living</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>condition</th>
      <th>grade</th>
      <th>sqft_above</th>
      <th>sqft_basement</th>
      <th>yr_built</th>
      <th>yr_renovated</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_living15</th>
      <th>sqft_lot15</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>221900.0</td>
      <td>3</td>
      <td>1.00</td>
      <td>1180</td>
      <td>5650</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>3</td>
      <td>7</td>
      <td>1180</td>
      <td>0.0</td>
      <td>1955</td>
      <td>0.0</td>
      <td>98178</td>
      <td>47.5112</td>
      <td>-122.257</td>
      <td>1340</td>
      <td>5650</td>
    </tr>
    <tr>
      <th>1</th>
      <td>538000.0</td>
      <td>3</td>
      <td>2.25</td>
      <td>2570</td>
      <td>7242</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>7</td>
      <td>2170</td>
      <td>400.0</td>
      <td>1951</td>
      <td>1991.0</td>
      <td>98125</td>
      <td>47.7210</td>
      <td>-122.319</td>
      <td>1690</td>
      <td>7639</td>
    </tr>
    <tr>
      <th>2</th>
      <td>180000.0</td>
      <td>2</td>
      <td>1.00</td>
      <td>770</td>
      <td>10000</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>6</td>
      <td>770</td>
      <td>0.0</td>
      <td>1933</td>
      <td>NaN</td>
      <td>98028</td>
      <td>47.7379</td>
      <td>-122.233</td>
      <td>2720</td>
      <td>8062</td>
    </tr>
    <tr>
      <th>3</th>
      <td>604000.0</td>
      <td>4</td>
      <td>3.00</td>
      <td>1960</td>
      <td>5000</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5</td>
      <td>7</td>
      <td>1050</td>
      <td>910.0</td>
      <td>1965</td>
      <td>0.0</td>
      <td>98136</td>
      <td>47.5208</td>
      <td>-122.393</td>
      <td>1360</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>510000.0</td>
      <td>3</td>
      <td>2.00</td>
      <td>1680</td>
      <td>8080</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>8</td>
      <td>1680</td>
      <td>0.0</td>
      <td>1987</td>
      <td>0.0</td>
      <td>98074</td>
      <td>47.6168</td>
      <td>-122.045</td>
      <td>1800</td>
      <td>7503</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.isna().sum() #looking at how much missing data 
nulls = data.isnull().sum() #nice trick from James to whittle down which columns have missing data 
print(nulls[nulls > 0])
```

    waterfront      2376
    view              63
    yr_renovated    3842
    dtype: int64



```python
data.dropna(subset = ['view'], inplace = True)#dropping rows in view since it's missing less than 1% of values
```


```python
data.isnull().sum() / len(data.index) #checking again and now view has 0% missing data
                                      #what to do with the rest? 
```




    price            0.000000
    bedrooms         0.000000
    bathrooms        0.000000
    sqft_living      0.000000
    sqft_lot         0.000000
    floors           0.000000
    waterfront       0.110059
    view             0.000000
    condition        0.000000
    grade            0.000000
    sqft_above       0.000000
    sqft_basement    0.000000
    yr_built         0.000000
    yr_renovated     0.177858
    zipcode          0.000000
    lat              0.000000
    long             0.000000
    sqft_living15    0.000000
    sqft_lot15       0.000000
    dtype: float64




```python
data['waterfront'].describe()
```




    count    19164.000000
    mean         0.007566
    std          0.086657
    min          0.000000
    25%          0.000000
    50%          0.000000
    75%          0.000000
    max          1.000000
    Name: waterfront, dtype: float64




```python
data['waterfront'].fillna(data['waterfront'].median(), inplace=True)
```


```python
data.isnull().sum() / len(data.index)
```




    price            0.000000
    bedrooms         0.000000
    bathrooms        0.000000
    sqft_living      0.000000
    sqft_lot         0.000000
    floors           0.000000
    waterfront       0.000000
    view             0.000000
    condition        0.000000
    grade            0.000000
    sqft_above       0.000000
    sqft_basement    0.000000
    yr_built         0.000000
    yr_renovated     0.177858
    zipcode          0.000000
    lat              0.000000
    long             0.000000
    sqft_living15    0.000000
    sqft_lot15       0.000000
    dtype: float64




```python
data['yr_renovated'].describe()
```




    count    17704.000000
    mean        83.765025
    std        400.239690
    min          0.000000
    25%          0.000000
    50%          0.000000
    75%          0.000000
    max       2015.000000
    Name: yr_renovated, dtype: float64




```python
data.groupby('yr_renovated')['price'].describe().round(3)#i see that for yr_renovated with NaN, std = mean
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
    <tr>
      <th>yr_renovated</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0.0</th>
      <td>16961.0</td>
      <td>530401.031</td>
      <td>348593.885</td>
      <td>80000.0</td>
      <td>320000.00</td>
      <td>447500.0</td>
      <td>633000.0</td>
      <td>6890000.0</td>
    </tr>
    <tr>
      <th>1934.0</th>
      <td>1.0</td>
      <td>459950.000</td>
      <td>NaN</td>
      <td>459950.0</td>
      <td>459950.00</td>
      <td>459950.0</td>
      <td>459950.0</td>
      <td>459950.0</td>
    </tr>
    <tr>
      <th>1940.0</th>
      <td>2.0</td>
      <td>378400.000</td>
      <td>92065.303</td>
      <td>313300.0</td>
      <td>345850.00</td>
      <td>378400.0</td>
      <td>410950.0</td>
      <td>443500.0</td>
    </tr>
    <tr>
      <th>1944.0</th>
      <td>1.0</td>
      <td>521000.000</td>
      <td>NaN</td>
      <td>521000.0</td>
      <td>521000.00</td>
      <td>521000.0</td>
      <td>521000.0</td>
      <td>521000.0</td>
    </tr>
    <tr>
      <th>1945.0</th>
      <td>3.0</td>
      <td>398666.667</td>
      <td>155853.564</td>
      <td>256000.0</td>
      <td>315500.00</td>
      <td>375000.0</td>
      <td>470000.0</td>
      <td>565000.0</td>
    </tr>
    <tr>
      <th>1946.0</th>
      <td>1.0</td>
      <td>550000.000</td>
      <td>NaN</td>
      <td>550000.0</td>
      <td>550000.00</td>
      <td>550000.0</td>
      <td>550000.0</td>
      <td>550000.0</td>
    </tr>
    <tr>
      <th>1948.0</th>
      <td>1.0</td>
      <td>410000.000</td>
      <td>NaN</td>
      <td>410000.0</td>
      <td>410000.00</td>
      <td>410000.0</td>
      <td>410000.0</td>
      <td>410000.0</td>
    </tr>
    <tr>
      <th>1950.0</th>
      <td>1.0</td>
      <td>152900.000</td>
      <td>NaN</td>
      <td>152900.0</td>
      <td>152900.00</td>
      <td>152900.0</td>
      <td>152900.0</td>
      <td>152900.0</td>
    </tr>
    <tr>
      <th>1951.0</th>
      <td>1.0</td>
      <td>276000.000</td>
      <td>NaN</td>
      <td>276000.0</td>
      <td>276000.00</td>
      <td>276000.0</td>
      <td>276000.0</td>
      <td>276000.0</td>
    </tr>
    <tr>
      <th>1953.0</th>
      <td>1.0</td>
      <td>247500.000</td>
      <td>NaN</td>
      <td>247500.0</td>
      <td>247500.00</td>
      <td>247500.0</td>
      <td>247500.0</td>
      <td>247500.0</td>
    </tr>
    <tr>
      <th>1954.0</th>
      <td>1.0</td>
      <td>900000.000</td>
      <td>NaN</td>
      <td>900000.0</td>
      <td>900000.00</td>
      <td>900000.0</td>
      <td>900000.0</td>
      <td>900000.0</td>
    </tr>
    <tr>
      <th>1955.0</th>
      <td>3.0</td>
      <td>442166.667</td>
      <td>94003.103</td>
      <td>377500.0</td>
      <td>388250.00</td>
      <td>399000.0</td>
      <td>474500.0</td>
      <td>550000.0</td>
    </tr>
    <tr>
      <th>1956.0</th>
      <td>3.0</td>
      <td>930666.667</td>
      <td>380028.069</td>
      <td>492000.0</td>
      <td>816000.00</td>
      <td>1140000.0</td>
      <td>1150000.0</td>
      <td>1160000.0</td>
    </tr>
    <tr>
      <th>1957.0</th>
      <td>2.0</td>
      <td>312350.000</td>
      <td>204141.728</td>
      <td>168000.0</td>
      <td>240175.00</td>
      <td>312350.0</td>
      <td>384525.0</td>
      <td>456700.0</td>
    </tr>
    <tr>
      <th>1958.0</th>
      <td>3.0</td>
      <td>694626.667</td>
      <td>559488.381</td>
      <td>346500.0</td>
      <td>371940.00</td>
      <td>397380.0</td>
      <td>868690.0</td>
      <td>1340000.0</td>
    </tr>
    <tr>
      <th>1959.0</th>
      <td>1.0</td>
      <td>397500.000</td>
      <td>NaN</td>
      <td>397500.0</td>
      <td>397500.00</td>
      <td>397500.0</td>
      <td>397500.0</td>
      <td>397500.0</td>
    </tr>
    <tr>
      <th>1960.0</th>
      <td>3.0</td>
      <td>252900.000</td>
      <td>124986.919</td>
      <td>160000.0</td>
      <td>181850.00</td>
      <td>203700.0</td>
      <td>299350.0</td>
      <td>395000.0</td>
    </tr>
    <tr>
      <th>1962.0</th>
      <td>2.0</td>
      <td>615000.000</td>
      <td>268700.577</td>
      <td>425000.0</td>
      <td>520000.00</td>
      <td>615000.0</td>
      <td>710000.0</td>
      <td>805000.0</td>
    </tr>
    <tr>
      <th>1963.0</th>
      <td>4.0</td>
      <td>497712.500</td>
      <td>374385.849</td>
      <td>185850.0</td>
      <td>226462.50</td>
      <td>402500.0</td>
      <td>673750.0</td>
      <td>1000000.0</td>
    </tr>
    <tr>
      <th>1964.0</th>
      <td>5.0</td>
      <td>356720.000</td>
      <td>129885.399</td>
      <td>225000.0</td>
      <td>302100.00</td>
      <td>325000.0</td>
      <td>360000.0</td>
      <td>571500.0</td>
    </tr>
    <tr>
      <th>1965.0</th>
      <td>4.0</td>
      <td>877750.000</td>
      <td>805771.835</td>
      <td>214000.0</td>
      <td>488500.00</td>
      <td>623500.0</td>
      <td>1012750.0</td>
      <td>2050000.0</td>
    </tr>
    <tr>
      <th>1967.0</th>
      <td>2.0</td>
      <td>268600.000</td>
      <td>30264.170</td>
      <td>247200.0</td>
      <td>257900.00</td>
      <td>268600.0</td>
      <td>279300.0</td>
      <td>290000.0</td>
    </tr>
    <tr>
      <th>1968.0</th>
      <td>7.0</td>
      <td>487100.000</td>
      <td>348611.728</td>
      <td>250000.0</td>
      <td>285850.00</td>
      <td>400000.0</td>
      <td>469000.0</td>
      <td>1250000.0</td>
    </tr>
    <tr>
      <th>1969.0</th>
      <td>4.0</td>
      <td>529125.000</td>
      <td>253616.632</td>
      <td>230000.0</td>
      <td>366125.00</td>
      <td>555750.0</td>
      <td>718750.0</td>
      <td>775000.0</td>
    </tr>
    <tr>
      <th>1970.0</th>
      <td>9.0</td>
      <td>523044.444</td>
      <td>183617.649</td>
      <td>335000.0</td>
      <td>397950.00</td>
      <td>450000.0</td>
      <td>569000.0</td>
      <td>876650.0</td>
    </tr>
    <tr>
      <th>1971.0</th>
      <td>1.0</td>
      <td>451555.000</td>
      <td>NaN</td>
      <td>451555.0</td>
      <td>451555.00</td>
      <td>451555.0</td>
      <td>451555.0</td>
      <td>451555.0</td>
    </tr>
    <tr>
      <th>1972.0</th>
      <td>3.0</td>
      <td>413000.000</td>
      <td>189032.405</td>
      <td>195000.0</td>
      <td>353750.00</td>
      <td>512500.0</td>
      <td>522000.0</td>
      <td>531500.0</td>
    </tr>
    <tr>
      <th>1973.0</th>
      <td>4.0</td>
      <td>411500.000</td>
      <td>88293.073</td>
      <td>290000.0</td>
      <td>380000.00</td>
      <td>430000.0</td>
      <td>461500.0</td>
      <td>496000.0</td>
    </tr>
    <tr>
      <th>1974.0</th>
      <td>2.0</td>
      <td>448750.000</td>
      <td>408354.166</td>
      <td>160000.0</td>
      <td>304375.00</td>
      <td>448750.0</td>
      <td>593125.0</td>
      <td>737500.0</td>
    </tr>
    <tr>
      <th>1975.0</th>
      <td>5.0</td>
      <td>532300.000</td>
      <td>171835.532</td>
      <td>273000.0</td>
      <td>447500.00</td>
      <td>596000.0</td>
      <td>660000.0</td>
      <td>685000.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1986.0</th>
      <td>14.0</td>
      <td>577392.143</td>
      <td>312307.866</td>
      <td>252000.0</td>
      <td>412500.00</td>
      <td>506000.0</td>
      <td>592500.0</td>
      <td>1550000.0</td>
    </tr>
    <tr>
      <th>1987.0</th>
      <td>14.0</td>
      <td>1387571.429</td>
      <td>2008522.418</td>
      <td>212000.0</td>
      <td>505500.00</td>
      <td>674000.0</td>
      <td>842875.0</td>
      <td>7700000.0</td>
    </tr>
    <tr>
      <th>1988.0</th>
      <td>11.0</td>
      <td>666636.364</td>
      <td>290003.542</td>
      <td>259000.0</td>
      <td>511000.00</td>
      <td>588000.0</td>
      <td>825000.0</td>
      <td>1300000.0</td>
    </tr>
    <tr>
      <th>1989.0</th>
      <td>20.0</td>
      <td>628517.500</td>
      <td>443204.741</td>
      <td>135000.0</td>
      <td>291600.00</td>
      <td>560000.0</td>
      <td>754212.5</td>
      <td>1800000.0</td>
    </tr>
    <tr>
      <th>1990.0</th>
      <td>22.0</td>
      <td>788090.909</td>
      <td>410986.636</td>
      <td>210000.0</td>
      <td>466250.00</td>
      <td>750000.0</td>
      <td>956000.0</td>
      <td>1650000.0</td>
    </tr>
    <tr>
      <th>1991.0</th>
      <td>16.0</td>
      <td>911931.250</td>
      <td>537746.603</td>
      <td>248500.0</td>
      <td>641000.00</td>
      <td>741500.0</td>
      <td>1025000.0</td>
      <td>2530000.0</td>
    </tr>
    <tr>
      <th>1992.0</th>
      <td>13.0</td>
      <td>699692.308</td>
      <td>466880.674</td>
      <td>234000.0</td>
      <td>354000.00</td>
      <td>538000.0</td>
      <td>1010000.0</td>
      <td>1650000.0</td>
    </tr>
    <tr>
      <th>1993.0</th>
      <td>12.0</td>
      <td>793755.000</td>
      <td>576511.308</td>
      <td>186000.0</td>
      <td>473500.00</td>
      <td>699975.0</td>
      <td>917015.0</td>
      <td>2370000.0</td>
    </tr>
    <tr>
      <th>1994.0</th>
      <td>14.0</td>
      <td>913393.143</td>
      <td>639263.195</td>
      <td>430000.0</td>
      <td>470500.00</td>
      <td>640002.0</td>
      <td>937000.0</td>
      <td>2350000.0</td>
    </tr>
    <tr>
      <th>1995.0</th>
      <td>11.0</td>
      <td>856770.000</td>
      <td>747852.029</td>
      <td>193500.0</td>
      <td>340000.00</td>
      <td>629000.0</td>
      <td>1070000.0</td>
      <td>2650000.0</td>
    </tr>
    <tr>
      <th>1996.0</th>
      <td>11.0</td>
      <td>706813.636</td>
      <td>334062.093</td>
      <td>200000.0</td>
      <td>571000.00</td>
      <td>649950.0</td>
      <td>834000.0</td>
      <td>1320000.0</td>
    </tr>
    <tr>
      <th>1997.0</th>
      <td>12.0</td>
      <td>550078.333</td>
      <td>287247.665</td>
      <td>199990.0</td>
      <td>265750.00</td>
      <td>523225.0</td>
      <td>732375.0</td>
      <td>1010000.0</td>
    </tr>
    <tr>
      <th>1998.0</th>
      <td>16.0</td>
      <td>744743.750</td>
      <td>454836.451</td>
      <td>253000.0</td>
      <td>455000.00</td>
      <td>518000.0</td>
      <td>957500.0</td>
      <td>1750000.0</td>
    </tr>
    <tr>
      <th>1999.0</th>
      <td>15.0</td>
      <td>1022100.000</td>
      <td>561298.946</td>
      <td>350000.0</td>
      <td>693750.00</td>
      <td>840000.0</td>
      <td>1285000.0</td>
      <td>2500000.0</td>
    </tr>
    <tr>
      <th>2000.0</th>
      <td>29.0</td>
      <td>805860.345</td>
      <td>398169.227</td>
      <td>295000.0</td>
      <td>550000.00</td>
      <td>770000.0</td>
      <td>935000.0</td>
      <td>1950000.0</td>
    </tr>
    <tr>
      <th>2001.0</th>
      <td>15.0</td>
      <td>1238720.000</td>
      <td>1671964.466</td>
      <td>215000.0</td>
      <td>583000.00</td>
      <td>745000.0</td>
      <td>1190000.0</td>
      <td>7060000.0</td>
    </tr>
    <tr>
      <th>2002.0</th>
      <td>17.0</td>
      <td>1267526.471</td>
      <td>943278.084</td>
      <td>397950.0</td>
      <td>664000.00</td>
      <td>880000.0</td>
      <td>1540000.0</td>
      <td>3600000.0</td>
    </tr>
    <tr>
      <th>2003.0</th>
      <td>31.0</td>
      <td>930161.290</td>
      <td>566700.162</td>
      <td>134000.0</td>
      <td>515000.00</td>
      <td>765000.0</td>
      <td>1220000.0</td>
      <td>2410000.0</td>
    </tr>
    <tr>
      <th>2004.0</th>
      <td>22.0</td>
      <td>739272.727</td>
      <td>427835.965</td>
      <td>285000.0</td>
      <td>415625.00</td>
      <td>686250.0</td>
      <td>907500.0</td>
      <td>2190000.0</td>
    </tr>
    <tr>
      <th>2005.0</th>
      <td>29.0</td>
      <td>834429.310</td>
      <td>491548.731</td>
      <td>190000.0</td>
      <td>430000.00</td>
      <td>744000.0</td>
      <td>1100000.0</td>
      <td>2400000.0</td>
    </tr>
    <tr>
      <th>2006.0</th>
      <td>20.0</td>
      <td>837872.500</td>
      <td>512243.761</td>
      <td>275000.0</td>
      <td>421800.00</td>
      <td>726300.0</td>
      <td>1102500.0</td>
      <td>2160000.0</td>
    </tr>
    <tr>
      <th>2007.0</th>
      <td>30.0</td>
      <td>890575.833</td>
      <td>540988.986</td>
      <td>110000.0</td>
      <td>543156.25</td>
      <td>850000.0</td>
      <td>960700.0</td>
      <td>2750000.0</td>
    </tr>
    <tr>
      <th>2008.0</th>
      <td>15.0</td>
      <td>973865.333</td>
      <td>746679.229</td>
      <td>287000.0</td>
      <td>356250.00</td>
      <td>900000.0</td>
      <td>1230000.0</td>
      <td>3000000.0</td>
    </tr>
    <tr>
      <th>2009.0</th>
      <td>21.0</td>
      <td>922381.524</td>
      <td>1007847.082</td>
      <td>146000.0</td>
      <td>420000.00</td>
      <td>525000.0</td>
      <td>875000.0</td>
      <td>4670000.0</td>
    </tr>
    <tr>
      <th>2010.0</th>
      <td>15.0</td>
      <td>1051936.667</td>
      <td>747033.187</td>
      <td>297950.0</td>
      <td>640000.00</td>
      <td>925000.0</td>
      <td>1185000.0</td>
      <td>3400000.0</td>
    </tr>
    <tr>
      <th>2011.0</th>
      <td>9.0</td>
      <td>531416.667</td>
      <td>194776.956</td>
      <td>329000.0</td>
      <td>378750.00</td>
      <td>507000.0</td>
      <td>650000.0</td>
      <td>831000.0</td>
    </tr>
    <tr>
      <th>2012.0</th>
      <td>8.0</td>
      <td>633375.000</td>
      <td>256891.132</td>
      <td>294000.0</td>
      <td>475000.00</td>
      <td>568750.0</td>
      <td>888750.0</td>
      <td>970500.0</td>
    </tr>
    <tr>
      <th>2013.0</th>
      <td>31.0</td>
      <td>674275.806</td>
      <td>445043.415</td>
      <td>224000.0</td>
      <td>402250.00</td>
      <td>570000.0</td>
      <td>854400.0</td>
      <td>2500000.0</td>
    </tr>
    <tr>
      <th>2014.0</th>
      <td>73.0</td>
      <td>666537.521</td>
      <td>327087.003</td>
      <td>199990.0</td>
      <td>433000.00</td>
      <td>599000.0</td>
      <td>811000.0</td>
      <td>1700000.0</td>
    </tr>
    <tr>
      <th>2015.0</th>
      <td>14.0</td>
      <td>697464.286</td>
      <td>308677.356</td>
      <td>285000.0</td>
      <td>463250.00</td>
      <td>761000.0</td>
      <td>828750.0</td>
      <td>1490000.0</td>
    </tr>
  </tbody>
</table>
<p>70 rows × 8 columns</p>
</div>




```python
# Using Binary Code and creating new column that makes it easier whether a house has been renovated (1) or not (0) 
```


```python
data['yr_renovated'].replace(0.0,np.nan,inplace=True)
```


```python
nan = data['yr_renovated'].loc[data['yr_renovated'].isna()].index #getting index to create a new column 
notnan = data['yr_renovated'].loc[~data['yr_renovated'].isna()].index
```


```python
data['new_yr_renovated'] = data['yr_renovated'].copy 
data['new_yr_renovated'][nan] = 0
data['new_yr_renovated'][notnan] = 1

data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 21534 entries, 0 to 21596
    Data columns (total 20 columns):
    price               21534 non-null float64
    bedrooms            21534 non-null int64
    bathrooms           21534 non-null float64
    sqft_living         21534 non-null int64
    sqft_lot            21534 non-null int64
    floors              21534 non-null float64
    waterfront          21534 non-null float64
    view                21534 non-null float64
    condition           21534 non-null int64
    grade               21534 non-null int64
    sqft_above          21534 non-null int64
    sqft_basement       21534 non-null object
    yr_built            21534 non-null int64
    yr_renovated        743 non-null float64
    zipcode             21534 non-null int64
    lat                 21534 non-null float64
    long                21534 non-null float64
    sqft_living15       21534 non-null int64
    sqft_lot15          21534 non-null int64
    new_yr_renovated    21534 non-null int64
    dtypes: float64(8), int64(11), object(1)
    memory usage: 4.1+ MB


    /Users/johnofrecio/anaconda3/lib/python3.7/site-packages/ipykernel_launcher.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      
    /Users/johnofrecio/anaconda3/lib/python3.7/site-packages/ipykernel_launcher.py:3: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      This is separate from the ipykernel package so we can avoid doing imports until



```python
data.drop(['yr_renovated'], axis = 1, inplace =True) #dropping yr_renovated
```


```python
data.isnull().sum() / len(data.index) #no more missing data 
```




    price               0.0
    bedrooms            0.0
    bathrooms           0.0
    sqft_living         0.0
    sqft_lot            0.0
    floors              0.0
    waterfront          0.0
    view                0.0
    condition           0.0
    grade               0.0
    sqft_above          0.0
    sqft_basement       0.0
    yr_built            0.0
    zipcode             0.0
    lat                 0.0
    long                0.0
    sqft_living15       0.0
    sqft_lot15          0.0
    new_yr_renovated    0.0
    dtype: float64



# Categorical Values


```python
for i in range(0, len(data.columns), 5): #visualizing comparing characteristics to price 
    sns.pairplot(data=data,
                x_vars=data.columns[i:i+5],
                y_vars=['price'])
```


![png](output_26_0.png)



![png](output_26_1.png)



![png](output_26_2.png)



![png](output_26_3.png)



```python
data.describe().round(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>sqft_living</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>condition</th>
      <th>grade</th>
      <th>sqft_above</th>
      <th>yr_built</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_living15</th>
      <th>sqft_lot15</th>
      <th>new_yr_renovated</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>540057.664</td>
      <td>3.373</td>
      <td>2.116</td>
      <td>2079.828</td>
      <td>15090.596</td>
      <td>1.494</td>
      <td>0.007</td>
      <td>0.234</td>
      <td>3.410</td>
      <td>7.657</td>
      <td>1788.558</td>
      <td>1971.002</td>
      <td>98077.939</td>
      <td>47.560</td>
      <td>-122.214</td>
      <td>1986.300</td>
      <td>12751.080</td>
      <td>0.035</td>
    </tr>
    <tr>
      <th>std</th>
      <td>366059.581</td>
      <td>0.926</td>
      <td>0.769</td>
      <td>917.447</td>
      <td>41380.210</td>
      <td>0.540</td>
      <td>0.082</td>
      <td>0.766</td>
      <td>0.651</td>
      <td>1.173</td>
      <td>827.746</td>
      <td>29.376</td>
      <td>53.507</td>
      <td>0.139</td>
      <td>0.141</td>
      <td>685.121</td>
      <td>27255.483</td>
      <td>0.183</td>
    </tr>
    <tr>
      <th>min</th>
      <td>78000.000</td>
      <td>1.000</td>
      <td>0.500</td>
      <td>370.000</td>
      <td>520.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>3.000</td>
      <td>370.000</td>
      <td>1900.000</td>
      <td>98001.000</td>
      <td>47.156</td>
      <td>-122.519</td>
      <td>399.000</td>
      <td>651.000</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>322000.000</td>
      <td>3.000</td>
      <td>1.750</td>
      <td>1430.000</td>
      <td>5040.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>3.000</td>
      <td>7.000</td>
      <td>1190.000</td>
      <td>1951.000</td>
      <td>98033.000</td>
      <td>47.471</td>
      <td>-122.328</td>
      <td>1490.000</td>
      <td>5100.000</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>450000.000</td>
      <td>3.000</td>
      <td>2.250</td>
      <td>1910.000</td>
      <td>7617.000</td>
      <td>1.500</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>3.000</td>
      <td>7.000</td>
      <td>1560.000</td>
      <td>1975.000</td>
      <td>98065.000</td>
      <td>47.572</td>
      <td>-122.230</td>
      <td>1840.000</td>
      <td>7620.000</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>645000.000</td>
      <td>4.000</td>
      <td>2.500</td>
      <td>2550.000</td>
      <td>10687.750</td>
      <td>2.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>4.000</td>
      <td>8.000</td>
      <td>2210.000</td>
      <td>1997.000</td>
      <td>98118.000</td>
      <td>47.678</td>
      <td>-122.125</td>
      <td>2360.000</td>
      <td>10083.000</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>7700000.000</td>
      <td>33.000</td>
      <td>8.000</td>
      <td>13540.000</td>
      <td>1651359.000</td>
      <td>3.500</td>
      <td>1.000</td>
      <td>4.000</td>
      <td>5.000</td>
      <td>13.000</td>
      <td>9410.000</td>
      <td>2015.000</td>
      <td>98199.000</td>
      <td>47.778</td>
      <td>-121.315</td>
      <td>6210.000</td>
      <td>871200.000</td>
      <td>1.000</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig = pd.plotting.scatter_matrix(data, figsize=(16,16));
```


![png](output_28_0.png)


# Observation
**Categorical Values**: view, waterfront, zipcode

**Ordinal Data**: bedrooms, bathrooms, floors, view, grade,  

# Transforming Categorical Values 


```python
data.info() #sqft_basement is an object 
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 21534 entries, 0 to 21596
    Data columns (total 19 columns):
    price               21534 non-null float64
    bedrooms            21534 non-null int64
    bathrooms           21534 non-null float64
    sqft_living         21534 non-null int64
    sqft_lot            21534 non-null int64
    floors              21534 non-null float64
    waterfront          21534 non-null float64
    view                21534 non-null float64
    condition           21534 non-null int64
    grade               21534 non-null int64
    sqft_above          21534 non-null int64
    sqft_basement       21534 non-null object
    yr_built            21534 non-null int64
    zipcode             21534 non-null int64
    lat                 21534 non-null float64
    long                21534 non-null float64
    sqft_living15       21534 non-null int64
    sqft_lot15          21534 non-null int64
    new_yr_renovated    21534 non-null int64
    dtypes: float64(7), int64(11), object(1)
    memory usage: 3.9+ MB



```python
basement = data['sqft_basement']
basement_series = pd.Series(basement)
basement_series
```




    0           0.0
    1         400.0
    2           0.0
    3         910.0
    4           0.0
    5        1530.0
    6             ?
    8         730.0
    9           0.0
    10       1700.0
    11        300.0
    12          0.0
    13          0.0
    14          0.0
    15        970.0
    16          0.0
    17          0.0
    18            ?
    19          0.0
    20        760.0
    21        720.0
    22          0.0
    23          0.0
    24          0.0
    25          0.0
    26        700.0
    27          0.0
    28        730.0
    29          0.0
    30          0.0
              ...  
    21566     280.0
    21567       0.0
    21568     320.0
    21569       0.0
    21570       0.0
    21571       0.0
    21572     190.0
    21573       0.0
    21574    1800.0
    21575       0.0
    21576       0.0
    21577       0.0
    21578       0.0
    21579      50.0
    21580       0.0
    21581         ?
    21582       0.0
    21583       0.0
    21584       0.0
    21585       0.0
    21586       0.0
    21587       0.0
    21588       0.0
    21590     910.0
    21591     130.0
    21592       0.0
    21593       0.0
    21594       0.0
    21595       0.0
    21596       0.0
    Name: sqft_basement, Length: 21534, dtype: object




```python
basement_series.describe()
```




    count     21534
    unique      302
    top         0.0
    freq      12798
    Name: sqft_basement, dtype: object




```python
cat_basement= basement_series.astype('category')
cat_basement
```




    0           0.0
    1         400.0
    2           0.0
    3         910.0
    4           0.0
    5        1530.0
    6             ?
    8         730.0
    9           0.0
    10       1700.0
    11        300.0
    12          0.0
    13          0.0
    14          0.0
    15        970.0
    16          0.0
    17          0.0
    18            ?
    19          0.0
    20        760.0
    21        720.0
    22          0.0
    23          0.0
    24          0.0
    25          0.0
    26        700.0
    27          0.0
    28        730.0
    29          0.0
    30          0.0
              ...  
    21566     280.0
    21567       0.0
    21568     320.0
    21569       0.0
    21570       0.0
    21571       0.0
    21572     190.0
    21573       0.0
    21574    1800.0
    21575       0.0
    21576       0.0
    21577       0.0
    21578       0.0
    21579      50.0
    21580       0.0
    21581         ?
    21582       0.0
    21583       0.0
    21584       0.0
    21585       0.0
    21586       0.0
    21587       0.0
    21588       0.0
    21590     910.0
    21591     130.0
    21592       0.0
    21593       0.0
    21594       0.0
    21595       0.0
    21596       0.0
    Name: sqft_basement, Length: 21534, dtype: category
    Categories (302, object): [0.0, 10.0, 100.0, 1000.0, ..., 970.0, 980.0, 990.0, ?]




```python
coded_basement = cat_basement.cat.codes
coded_basement
```




    0          0
    1        207
    2          0
    3        289
    4          0
    5         73
    6        301
    8        262
    9          0
    10        93
    11       191
    12         0
    13         0
    14         0
    15       298
    16         0
    17         0
    18       301
    19         0
    20       265
    21       261
    22         0
    23         0
    24         0
    25         0
    26       258
    27         0
    28       262
    29         0
    30         0
            ... 
    21566    185
    21567      0
    21568    194
    21569      0
    21570      0
    21571      0
    21572    119
    21573      0
    21574    107
    21575      0
    21576      0
    21577      0
    21578      0
    21579    224
    21580      0
    21581    301
    21582      0
    21583      0
    21584      0
    21585      0
    21586      0
    21587      0
    21588      0
    21590    289
    21591     43
    21592      0
    21593      0
    21594      0
    21595      0
    21596      0
    Length: 21534, dtype: int16




```python
data['coded_basement'] = coded_basement
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>bedrooms</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>condition</th>
      <th>grade</th>
      <th>sqft_basement</th>
      <th>yr_built</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_lot15</th>
      <th>new_yr_renovated</th>
      <th>bathrooms_log</th>
      <th>sqft_living15_log</th>
      <th>coded_basement</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>221900.0</td>
      <td>3</td>
      <td>5650</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>7</td>
      <td>0.0</td>
      <td>1955</td>
      <td>98178</td>
      <td>47.5112</td>
      <td>-122.257</td>
      <td>5650</td>
      <td>0</td>
      <td>0.000000</td>
      <td>7.200425</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>538000.0</td>
      <td>3</td>
      <td>7242</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>7</td>
      <td>400.0</td>
      <td>1951</td>
      <td>98125</td>
      <td>47.7210</td>
      <td>-122.319</td>
      <td>7639</td>
      <td>1</td>
      <td>0.810930</td>
      <td>7.432484</td>
      <td>207</td>
    </tr>
    <tr>
      <th>2</th>
      <td>180000.0</td>
      <td>2</td>
      <td>10000</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>6</td>
      <td>0.0</td>
      <td>1933</td>
      <td>98028</td>
      <td>47.7379</td>
      <td>-122.233</td>
      <td>8062</td>
      <td>0</td>
      <td>0.000000</td>
      <td>7.908387</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>604000.0</td>
      <td>4</td>
      <td>5000</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5</td>
      <td>7</td>
      <td>910.0</td>
      <td>1965</td>
      <td>98136</td>
      <td>47.5208</td>
      <td>-122.393</td>
      <td>5000</td>
      <td>0</td>
      <td>1.098612</td>
      <td>7.215240</td>
      <td>289</td>
    </tr>
    <tr>
      <th>4</th>
      <td>510000.0</td>
      <td>3</td>
      <td>8080</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>8</td>
      <td>0.0</td>
      <td>1987</td>
      <td>98074</td>
      <td>47.6168</td>
      <td>-122.045</td>
      <td>7503</td>
      <td>0</td>
      <td>0.693147</td>
      <td>7.495542</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.drop(['sqft_basement'], axis = 1, inplace =True)
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>bedrooms</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>condition</th>
      <th>grade</th>
      <th>yr_built</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_lot15</th>
      <th>new_yr_renovated</th>
      <th>bathrooms_log</th>
      <th>sqft_living15_log</th>
      <th>coded_basement</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>221900.0</td>
      <td>3</td>
      <td>5650</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>7</td>
      <td>1955</td>
      <td>98178</td>
      <td>47.5112</td>
      <td>-122.257</td>
      <td>5650</td>
      <td>0</td>
      <td>0.000000</td>
      <td>7.200425</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>538000.0</td>
      <td>3</td>
      <td>7242</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>7</td>
      <td>1951</td>
      <td>98125</td>
      <td>47.7210</td>
      <td>-122.319</td>
      <td>7639</td>
      <td>1</td>
      <td>0.810930</td>
      <td>7.432484</td>
      <td>207</td>
    </tr>
    <tr>
      <th>2</th>
      <td>180000.0</td>
      <td>2</td>
      <td>10000</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>6</td>
      <td>1933</td>
      <td>98028</td>
      <td>47.7379</td>
      <td>-122.233</td>
      <td>8062</td>
      <td>0</td>
      <td>0.000000</td>
      <td>7.908387</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>604000.0</td>
      <td>4</td>
      <td>5000</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5</td>
      <td>7</td>
      <td>1965</td>
      <td>98136</td>
      <td>47.5208</td>
      <td>-122.393</td>
      <td>5000</td>
      <td>0</td>
      <td>1.098612</td>
      <td>7.215240</td>
      <td>289</td>
    </tr>
    <tr>
      <th>4</th>
      <td>510000.0</td>
      <td>3</td>
      <td>8080</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3</td>
      <td>8</td>
      <td>1987</td>
      <td>98074</td>
      <td>47.6168</td>
      <td>-122.045</td>
      <td>7503</td>
      <td>0</td>
      <td>0.693147</td>
      <td>7.495542</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



# Multicollinearity 


```python
data.corr().round(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>bedrooms</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>condition</th>
      <th>grade</th>
      <th>yr_built</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_lot15</th>
      <th>new_yr_renovated</th>
      <th>bathrooms_log</th>
      <th>sqft_living15_log</th>
      <th>coded_basement</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>price</th>
      <td>1.000</td>
      <td>0.308</td>
      <td>0.090</td>
      <td>0.257</td>
      <td>0.259</td>
      <td>0.396</td>
      <td>0.035</td>
      <td>0.668</td>
      <td>0.054</td>
      <td>-0.054</td>
      <td>0.308</td>
      <td>0.022</td>
      <td>0.083</td>
      <td>0.118</td>
      <td>0.456</td>
      <td>0.544</td>
      <td>0.076</td>
    </tr>
    <tr>
      <th>bedrooms</th>
      <td>0.308</td>
      <td>1.000</td>
      <td>0.033</td>
      <td>0.177</td>
      <td>-0.004</td>
      <td>0.079</td>
      <td>0.026</td>
      <td>0.356</td>
      <td>0.155</td>
      <td>-0.154</td>
      <td>-0.010</td>
      <td>0.132</td>
      <td>0.031</td>
      <td>0.018</td>
      <td>0.508</td>
      <td>0.406</td>
      <td>0.077</td>
    </tr>
    <tr>
      <th>sqft_lot</th>
      <td>0.090</td>
      <td>0.033</td>
      <td>1.000</td>
      <td>-0.005</td>
      <td>0.021</td>
      <td>0.075</td>
      <td>-0.008</td>
      <td>0.115</td>
      <td>0.053</td>
      <td>-0.130</td>
      <td>-0.085</td>
      <td>0.230</td>
      <td>0.717</td>
      <td>0.005</td>
      <td>0.076</td>
      <td>0.145</td>
      <td>-0.046</td>
    </tr>
    <tr>
      <th>floors</th>
      <td>0.257</td>
      <td>0.177</td>
      <td>-0.005</td>
      <td>1.000</td>
      <td>0.020</td>
      <td>0.028</td>
      <td>-0.264</td>
      <td>0.459</td>
      <td>0.489</td>
      <td>-0.059</td>
      <td>0.049</td>
      <td>0.125</td>
      <td>-0.011</td>
      <td>0.003</td>
      <td>0.501</td>
      <td>0.275</td>
      <td>-0.203</td>
    </tr>
    <tr>
      <th>waterfront</th>
      <td>0.259</td>
      <td>-0.004</td>
      <td>0.021</td>
      <td>0.020</td>
      <td>1.000</td>
      <td>0.382</td>
      <td>0.016</td>
      <td>0.081</td>
      <td>-0.025</td>
      <td>0.029</td>
      <td>-0.012</td>
      <td>-0.038</td>
      <td>0.031</td>
      <td>0.075</td>
      <td>0.046</td>
      <td>0.075</td>
      <td>0.009</td>
    </tr>
    <tr>
      <th>view</th>
      <td>0.396</td>
      <td>0.079</td>
      <td>0.075</td>
      <td>0.028</td>
      <td>0.382</td>
      <td>1.000</td>
      <td>0.046</td>
      <td>0.250</td>
      <td>-0.055</td>
      <td>0.085</td>
      <td>0.006</td>
      <td>-0.078</td>
      <td>0.073</td>
      <td>0.090</td>
      <td>0.158</td>
      <td>0.263</td>
      <td>0.087</td>
    </tr>
    <tr>
      <th>condition</th>
      <td>0.035</td>
      <td>0.026</td>
      <td>-0.008</td>
      <td>-0.264</td>
      <td>0.016</td>
      <td>0.046</td>
      <td>1.000</td>
      <td>-0.147</td>
      <td>-0.361</td>
      <td>0.002</td>
      <td>-0.016</td>
      <td>-0.105</td>
      <td>-0.003</td>
      <td>-0.055</td>
      <td>-0.113</td>
      <td>-0.089</td>
      <td>0.101</td>
    </tr>
    <tr>
      <th>grade</th>
      <td>0.668</td>
      <td>0.356</td>
      <td>0.115</td>
      <td>0.459</td>
      <td>0.081</td>
      <td>0.250</td>
      <td>-0.147</td>
      <td>1.000</td>
      <td>0.448</td>
      <td>-0.186</td>
      <td>0.114</td>
      <td>0.201</td>
      <td>0.121</td>
      <td>0.015</td>
      <td>0.644</td>
      <td>0.689</td>
      <td>-0.008</td>
    </tr>
    <tr>
      <th>yr_built</th>
      <td>0.054</td>
      <td>0.155</td>
      <td>0.053</td>
      <td>0.489</td>
      <td>-0.025</td>
      <td>-0.055</td>
      <td>-0.361</td>
      <td>0.448</td>
      <td>1.000</td>
      <td>-0.347</td>
      <td>-0.148</td>
      <td>0.410</td>
      <td>0.071</td>
      <td>-0.203</td>
      <td>0.534</td>
      <td>0.334</td>
      <td>-0.138</td>
    </tr>
    <tr>
      <th>zipcode</th>
      <td>-0.054</td>
      <td>-0.154</td>
      <td>-0.130</td>
      <td>-0.059</td>
      <td>0.029</td>
      <td>0.085</td>
      <td>0.002</td>
      <td>-0.186</td>
      <td>-0.347</td>
      <td>1.000</td>
      <td>0.267</td>
      <td>-0.564</td>
      <td>-0.148</td>
      <td>0.062</td>
      <td>-0.227</td>
      <td>-0.290</td>
      <td>0.141</td>
    </tr>
    <tr>
      <th>lat</th>
      <td>0.308</td>
      <td>-0.010</td>
      <td>-0.085</td>
      <td>0.049</td>
      <td>-0.012</td>
      <td>0.006</td>
      <td>-0.016</td>
      <td>0.114</td>
      <td>-0.148</td>
      <td>0.267</td>
      <td>1.000</td>
      <td>-0.135</td>
      <td>-0.086</td>
      <td>0.028</td>
      <td>0.011</td>
      <td>0.043</td>
      <td>0.098</td>
    </tr>
    <tr>
      <th>long</th>
      <td>0.022</td>
      <td>0.132</td>
      <td>0.230</td>
      <td>0.125</td>
      <td>-0.038</td>
      <td>-0.078</td>
      <td>-0.105</td>
      <td>0.201</td>
      <td>0.410</td>
      <td>-0.564</td>
      <td>-0.135</td>
      <td>1.000</td>
      <td>0.255</td>
      <td>-0.065</td>
      <td>0.241</td>
      <td>0.338</td>
      <td>-0.200</td>
    </tr>
    <tr>
      <th>sqft_lot15</th>
      <td>0.083</td>
      <td>0.031</td>
      <td>0.717</td>
      <td>-0.011</td>
      <td>0.031</td>
      <td>0.073</td>
      <td>-0.003</td>
      <td>0.121</td>
      <td>0.071</td>
      <td>-0.148</td>
      <td>-0.086</td>
      <td>0.255</td>
      <td>1.000</td>
      <td>0.005</td>
      <td>0.078</td>
      <td>0.179</td>
      <td>-0.048</td>
    </tr>
    <tr>
      <th>new_yr_renovated</th>
      <td>0.118</td>
      <td>0.018</td>
      <td>0.005</td>
      <td>0.003</td>
      <td>0.075</td>
      <td>0.090</td>
      <td>-0.055</td>
      <td>0.015</td>
      <td>-0.203</td>
      <td>0.062</td>
      <td>0.028</td>
      <td>-0.065</td>
      <td>0.005</td>
      <td>1.000</td>
      <td>0.038</td>
      <td>-0.003</td>
      <td>0.033</td>
    </tr>
    <tr>
      <th>bathrooms_log</th>
      <td>0.456</td>
      <td>0.508</td>
      <td>0.076</td>
      <td>0.501</td>
      <td>0.046</td>
      <td>0.158</td>
      <td>-0.113</td>
      <td>0.644</td>
      <td>0.534</td>
      <td>-0.227</td>
      <td>0.011</td>
      <td>0.241</td>
      <td>0.078</td>
      <td>0.038</td>
      <td>1.000</td>
      <td>0.570</td>
      <td>0.108</td>
    </tr>
    <tr>
      <th>sqft_living15_log</th>
      <td>0.544</td>
      <td>0.406</td>
      <td>0.145</td>
      <td>0.275</td>
      <td>0.075</td>
      <td>0.263</td>
      <td>-0.089</td>
      <td>0.689</td>
      <td>0.334</td>
      <td>-0.290</td>
      <td>0.043</td>
      <td>0.338</td>
      <td>0.179</td>
      <td>-0.003</td>
      <td>0.570</td>
      <td>1.000</td>
      <td>-0.001</td>
    </tr>
    <tr>
      <th>coded_basement</th>
      <td>0.076</td>
      <td>0.077</td>
      <td>-0.046</td>
      <td>-0.203</td>
      <td>0.009</td>
      <td>0.087</td>
      <td>0.101</td>
      <td>-0.008</td>
      <td>-0.138</td>
      <td>0.141</td>
      <td>0.098</td>
      <td>-0.200</td>
      <td>-0.048</td>
      <td>0.033</td>
      <td>0.108</td>
      <td>-0.001</td>
      <td>1.000</td>
    </tr>
  </tbody>
</table>
</div>




```python
corr = data.corr()
mask = np.zeros_like(corr)
mask[np.triu_indices_from(mask)] = True

f, ax = plt.subplots(figsize=(15, 20))

sns.heatmap(corr, mask=mask, cmap='coolwarm', vmax=1, center=0,
            square=True, linewidths=.5,annot=True, cbar_kws={"shrink": .5});
```


![png](output_40_0.png)


# Observation: 
   **sqft_living** and **sqft_above** show high correality 


```python
try:
    drop_cols = ['sqft_living', 'sqft_above']
    data.drop(drop_cols, axis=1, inplace=True)
except: 
    print('drop_cols were not in the dataframe')
```

    drop_cols were not in the dataframe



```python
corr = data.corr()
mask = np.zeros_like(corr)
mask[np.triu_indices_from(mask)] = True

f, ax = plt.subplots(figsize=(15, 20))

sns.heatmap(corr, mask=mask, cmap='coolwarm', vmax=1, center=0,
            square=True, linewidths=.5,annot=True, cbar_kws={"shrink": .5});
```


![png](output_43_0.png)


# Normalization: Log Transformation 


```python
import matplotlib as mpl
mpl.rcParams['figure.figsize'] =(16,16)
data.hist();
```


![png](output_45_0.png)



```python
log_cols= ['bathrooms','sqft_living15','yr_built','zipcode']

for col in log_cols:
    data[col+'_log'] = np.log(data[col])
    
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    ~/anaconda3/lib/python3.7/site-packages/pandas/core/indexes/base.py in get_loc(self, key, method, tolerance)
       2656             try:
    -> 2657                 return self._engine.get_loc(key)
       2658             except KeyError:


    pandas/_libs/index.pyx in pandas._libs.index.IndexEngine.get_loc()


    pandas/_libs/index.pyx in pandas._libs.index.IndexEngine.get_loc()


    pandas/_libs/hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()


    pandas/_libs/hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()


    KeyError: 'bathrooms'

    
    During handling of the above exception, another exception occurred:


    KeyError                                  Traceback (most recent call last)

    <ipython-input-123-e82d1e9c9bd5> in <module>
          2 
          3 for col in log_cols:
    ----> 4     data[col+'_log'] = np.log(data[col])
          5 


    ~/anaconda3/lib/python3.7/site-packages/pandas/core/frame.py in __getitem__(self, key)
       2925             if self.columns.nlevels > 1:
       2926                 return self._getitem_multilevel(key)
    -> 2927             indexer = self.columns.get_loc(key)
       2928             if is_integer(indexer):
       2929                 indexer = [indexer]


    ~/anaconda3/lib/python3.7/site-packages/pandas/core/indexes/base.py in get_loc(self, key, method, tolerance)
       2657                 return self._engine.get_loc(key)
       2658             except KeyError:
    -> 2659                 return self._engine.get_loc(self._maybe_cast_indexer(key))
       2660         indexer = self.get_indexer([key], method=method, tolerance=tolerance)
       2661         if indexer.ndim > 1 or indexer.size > 1:


    pandas/_libs/index.pyx in pandas._libs.index.IndexEngine.get_loc()


    pandas/_libs/index.pyx in pandas._libs.index.IndexEngine.get_loc()


    pandas/_libs/hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()


    pandas/_libs/hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()


    KeyError: 'bathrooms'



```python
data.hist();
```


![png](output_47_0.png)


# Observation: 
It looks like **bathrooms_log** and **sqft_living15_log** normalized using log. The other log columns did not change. 


```python
data.drop('bathrooms', axis=1, inplace=True)
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    <ipython-input-125-305bf5ff13bd> in <module>
    ----> 1 data.drop('bathrooms', axis=1, inplace=True)
    

    ~/anaconda3/lib/python3.7/site-packages/pandas/core/frame.py in drop(self, labels, axis, index, columns, level, inplace, errors)
       3938                                            index=index, columns=columns,
       3939                                            level=level, inplace=inplace,
    -> 3940                                            errors=errors)
       3941 
       3942     @rewrite_axis_style_signature('mapper', [('copy', True),


    ~/anaconda3/lib/python3.7/site-packages/pandas/core/generic.py in drop(self, labels, axis, index, columns, level, inplace, errors)
       3778         for axis, labels in axes.items():
       3779             if labels is not None:
    -> 3780                 obj = obj._drop_axis(labels, axis, level=level, errors=errors)
       3781 
       3782         if inplace:


    ~/anaconda3/lib/python3.7/site-packages/pandas/core/generic.py in _drop_axis(self, labels, axis, level, errors)
       3810                 new_axis = axis.drop(labels, level=level, errors=errors)
       3811             else:
    -> 3812                 new_axis = axis.drop(labels, errors=errors)
       3813             result = self.reindex(**{axis_name: new_axis})
       3814 


    ~/anaconda3/lib/python3.7/site-packages/pandas/core/indexes/base.py in drop(self, labels, errors)
       4963             if errors != 'ignore':
       4964                 raise KeyError(
    -> 4965                     '{} not found in axis'.format(labels[mask]))
       4966             indexer = indexer[~mask]
       4967         return self.delete(indexer)


    KeyError: "['bathrooms'] not found in axis"



```python
data.drop('col_log', axis=1, inplace=True)
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    <ipython-input-37-e2a1d0b3765c> in <module>
    ----> 1 data.drop('col_log', axis=1, inplace=True)
    

    ~/anaconda3/lib/python3.7/site-packages/pandas/core/frame.py in drop(self, labels, axis, index, columns, level, inplace, errors)
       3938                                            index=index, columns=columns,
       3939                                            level=level, inplace=inplace,
    -> 3940                                            errors=errors)
       3941 
       3942     @rewrite_axis_style_signature('mapper', [('copy', True),


    ~/anaconda3/lib/python3.7/site-packages/pandas/core/generic.py in drop(self, labels, axis, index, columns, level, inplace, errors)
       3778         for axis, labels in axes.items():
       3779             if labels is not None:
    -> 3780                 obj = obj._drop_axis(labels, axis, level=level, errors=errors)
       3781 
       3782         if inplace:


    ~/anaconda3/lib/python3.7/site-packages/pandas/core/generic.py in _drop_axis(self, labels, axis, level, errors)
       3810                 new_axis = axis.drop(labels, level=level, errors=errors)
       3811             else:
    -> 3812                 new_axis = axis.drop(labels, errors=errors)
       3813             result = self.reindex(**{axis_name: new_axis})
       3814 


    ~/anaconda3/lib/python3.7/site-packages/pandas/core/indexes/base.py in drop(self, labels, errors)
       4963             if errors != 'ignore':
       4964                 raise KeyError(
    -> 4965                     '{} not found in axis'.format(labels[mask]))
       4966             indexer = indexer[~mask]
       4967         return self.delete(indexer)


    KeyError: "['col_log'] not found in axis"



```python
data.drop(['sqft_living15','yr_built_log','zipcode_log'], axis=1, inplace=True)
```


```python
data.hist();
```


![png](output_52_0.png)


# Standardization 
Categorical Values: **view**, **waterfront**, **zipcode**

Ordinal Data: **bedrooms**, **bathrooms**, **floors**, **view**, **grade**,


```python
data.describe().round(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>bedrooms</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>condition</th>
      <th>grade</th>
      <th>yr_built</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_lot15</th>
      <th>new_yr_renovated</th>
      <th>bathrooms_log</th>
      <th>sqft_living15_log</th>
      <th>coded_basement</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
      <td>21534.000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>540057.664</td>
      <td>3.373</td>
      <td>15090.596</td>
      <td>1.494</td>
      <td>0.007</td>
      <td>0.234</td>
      <td>3.410</td>
      <td>7.657</td>
      <td>1971.002</td>
      <td>98077.939</td>
      <td>47.560</td>
      <td>-122.214</td>
      <td>12751.080</td>
      <td>0.035</td>
      <td>0.678</td>
      <td>7.539</td>
      <td>77.159</td>
    </tr>
    <tr>
      <th>std</th>
      <td>366059.581</td>
      <td>0.926</td>
      <td>41380.210</td>
      <td>0.540</td>
      <td>0.082</td>
      <td>0.766</td>
      <td>0.651</td>
      <td>1.173</td>
      <td>29.376</td>
      <td>53.507</td>
      <td>0.139</td>
      <td>0.141</td>
      <td>27255.483</td>
      <td>0.183</td>
      <td>0.392</td>
      <td>0.327</td>
      <td>112.067</td>
    </tr>
    <tr>
      <th>min</th>
      <td>78000.000</td>
      <td>1.000</td>
      <td>520.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>3.000</td>
      <td>1900.000</td>
      <td>98001.000</td>
      <td>47.156</td>
      <td>-122.519</td>
      <td>651.000</td>
      <td>0.000</td>
      <td>-0.693</td>
      <td>5.989</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>322000.000</td>
      <td>3.000</td>
      <td>5040.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>3.000</td>
      <td>7.000</td>
      <td>1951.000</td>
      <td>98033.000</td>
      <td>47.471</td>
      <td>-122.328</td>
      <td>5100.000</td>
      <td>0.000</td>
      <td>0.560</td>
      <td>7.307</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>450000.000</td>
      <td>3.000</td>
      <td>7617.000</td>
      <td>1.500</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>3.000</td>
      <td>7.000</td>
      <td>1975.000</td>
      <td>98065.000</td>
      <td>47.572</td>
      <td>-122.230</td>
      <td>7620.000</td>
      <td>0.000</td>
      <td>0.811</td>
      <td>7.518</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>645000.000</td>
      <td>4.000</td>
      <td>10687.750</td>
      <td>2.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>4.000</td>
      <td>8.000</td>
      <td>1997.000</td>
      <td>98118.000</td>
      <td>47.678</td>
      <td>-122.125</td>
      <td>10083.000</td>
      <td>0.000</td>
      <td>0.916</td>
      <td>7.766</td>
      <td>201.000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>7700000.000</td>
      <td>33.000</td>
      <td>1651359.000</td>
      <td>3.500</td>
      <td>1.000</td>
      <td>4.000</td>
      <td>5.000</td>
      <td>13.000</td>
      <td>2015.000</td>
      <td>98199.000</td>
      <td>47.778</td>
      <td>-121.315</td>
      <td>871200.000</td>
      <td>1.000</td>
      <td>2.079</td>
      <td>8.734</td>
      <td>301.000</td>
    </tr>
  </tbody>
</table>
</div>




```python
cat_cols = ['waterfront','coded_basement']
num_cols = data.drop(['waterfront','coded_basement','price'],axis=1).columns
```


```python
num_cols
```




    Index(['bedrooms', 'sqft_lot', 'floors', 'view', 'condition', 'grade',
           'yr_built', 'zipcode', 'lat', 'long', 'sqft_lot15', 'new_yr_renovated',
           'bathrooms_log', 'sqft_living15_log'],
          dtype='object')




```python
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
```


```python
scaled_data = scaler.fit_transform(data[num_cols])
```

    /Users/johnofrecio/anaconda3/lib/python3.7/site-packages/sklearn/preprocessing/data.py:645: DataConversionWarning: Data with input dtype int64, float64 were all converted to float64 by StandardScaler.
      return self.partial_fit(X, y)
    /Users/johnofrecio/anaconda3/lib/python3.7/site-packages/sklearn/base.py:464: DataConversionWarning: Data with input dtype int64, float64 were all converted to float64 by StandardScaler.
      return self.fit(X, **fit_params).transform(X)



```python
try:
    scaled_data = scaler.fit_transform(data[num_cols])
except:
    print('I dont know what to do')
```

    /Users/johnofrecio/anaconda3/lib/python3.7/site-packages/sklearn/preprocessing/data.py:645: DataConversionWarning: Data with input dtype int64, float64 were all converted to float64 by StandardScaler.
      return self.partial_fit(X, y)
    /Users/johnofrecio/anaconda3/lib/python3.7/site-packages/sklearn/base.py:464: DataConversionWarning: Data with input dtype int64, float64 were all converted to float64 by StandardScaler.
      return self.fit(X, **fit_params).transform(X)


# Models 
Predictors: Based on the linear relationship to price, I will be testing my model using these 4 main variable: 
            1. Basement (**coded_basement**)
            2. The square footage of interior housing living space for the nearest 15 neighbors    (**sqft_living15_log**)
            3. The grade level of the house (**grade**)
            4. location (**lat**)


```python
from statsmodels.formula.api import ols
```


```python
outcome = 'price'
x_cols = ['coded_basement','sqft_living15_log', 'grade','lat']
predictors = '+'.join(x_cols)
formula = outcome + "~" + predictors
model = ols(formula=formula, data=data).fit()
model.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>price</td>      <th>  R-squared:         </th>  <td>   0.520</td>  
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th>  <td>   0.520</td>  
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th>  <td>   5841.</td>  
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 17 Nov 2019</td> <th>  Prob (F-statistic):</th>   <td>  0.00</td>   
</tr>
<tr>
  <th>Time:</th>                 <td>22:16:43</td>     <th>  Log-Likelihood:    </th> <td>-2.9850e+05</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td> 21534</td>      <th>  AIC:               </th>  <td>5.970e+05</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td> 21529</td>      <th>  BIC:               </th>  <td>5.971e+05</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>     4</td>      <th>                     </th>      <td> </td>     
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>      <td> </td>     
</tr>
</table>
<table class="simpletable">
<tr>
          <td></td>             <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>         <td>-3.177e+07</td> <td> 6.03e+05</td> <td>  -52.672</td> <td> 0.000</td> <td> -3.3e+07</td> <td>-3.06e+07</td>
</tr>
<tr>
  <th>coded_basement</th>    <td>  184.9195</td> <td>   15.495</td> <td>   11.934</td> <td> 0.000</td> <td>  154.548</td> <td>  215.291</td>
</tr>
<tr>
  <th>sqft_living15_log</th> <td> 1.954e+05</td> <td> 7285.865</td> <td>   26.822</td> <td> 0.000</td> <td> 1.81e+05</td> <td>  2.1e+05</td>
</tr>
<tr>
  <th>grade</th>             <td> 1.628e+05</td> <td> 2046.268</td> <td>   79.569</td> <td> 0.000</td> <td> 1.59e+05</td> <td> 1.67e+05</td>
</tr>
<tr>
  <th>lat</th>               <td> 6.219e+05</td> <td> 1.26e+04</td> <td>   49.236</td> <td> 0.000</td> <td> 5.97e+05</td> <td> 6.47e+05</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>22242.958</td> <th>  Durbin-Watson:     </th>  <td>   1.979</td>  
</tr>
<tr>
  <th>Prob(Omnibus):</th>  <td> 0.000</td>   <th>  Jarque-Bera (JB):  </th> <td>3441413.889</td>
</tr>
<tr>
  <th>Skew:</th>           <td> 4.834</td>   <th>  Prob(JB):          </th>  <td>    0.00</td>  
</tr>
<tr>
  <th>Kurtosis:</th>       <td>64.172</td>   <th>  Cond. No.          </th>  <td>4.86e+04</td>  
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 4.86e+04. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
pd.plotting.scatter_matrix(data[x_cols], figsize=(10,12));
```


![png](output_63_0.png)



```python
outcome = 'price'
predictors = (['coded_basement','sqft_living15_log', 'grade','lat'])
pred_sum = "+".join(predictors)
formula = outcome + "~" + pred_sum
```


```python
model = ols(formula= formula, data=data).fit()
model.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>price</td>      <th>  R-squared:         </th>  <td>   0.520</td>  
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th>  <td>   0.520</td>  
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th>  <td>   5841.</td>  
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 17 Nov 2019</td> <th>  Prob (F-statistic):</th>   <td>  0.00</td>   
</tr>
<tr>
  <th>Time:</th>                 <td>21:56:51</td>     <th>  Log-Likelihood:    </th> <td>-2.9850e+05</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td> 21534</td>      <th>  AIC:               </th>  <td>5.970e+05</td> 
</tr>
<tr>
  <th>Df Residuals:</th>          <td> 21529</td>      <th>  BIC:               </th>  <td>5.971e+05</td> 
</tr>
<tr>
  <th>Df Model:</th>              <td>     4</td>      <th>                     </th>      <td> </td>     
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>      <td> </td>     
</tr>
</table>
<table class="simpletable">
<tr>
          <td></td>             <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>         <td>-3.177e+07</td> <td> 6.03e+05</td> <td>  -52.672</td> <td> 0.000</td> <td> -3.3e+07</td> <td>-3.06e+07</td>
</tr>
<tr>
  <th>coded_basement</th>    <td>  184.9195</td> <td>   15.495</td> <td>   11.934</td> <td> 0.000</td> <td>  154.548</td> <td>  215.291</td>
</tr>
<tr>
  <th>sqft_living15_log</th> <td> 1.954e+05</td> <td> 7285.865</td> <td>   26.822</td> <td> 0.000</td> <td> 1.81e+05</td> <td>  2.1e+05</td>
</tr>
<tr>
  <th>grade</th>             <td> 1.628e+05</td> <td> 2046.268</td> <td>   79.569</td> <td> 0.000</td> <td> 1.59e+05</td> <td> 1.67e+05</td>
</tr>
<tr>
  <th>lat</th>               <td> 6.219e+05</td> <td> 1.26e+04</td> <td>   49.236</td> <td> 0.000</td> <td> 5.97e+05</td> <td> 6.47e+05</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>22242.958</td> <th>  Durbin-Watson:     </th>  <td>   1.979</td>  
</tr>
<tr>
  <th>Prob(Omnibus):</th>  <td> 0.000</td>   <th>  Jarque-Bera (JB):  </th> <td>3441413.889</td>
</tr>
<tr>
  <th>Skew:</th>           <td> 4.834</td>   <th>  Prob(JB):          </th>  <td>    0.00</td>  
</tr>
<tr>
  <th>Kurtosis:</th>       <td>64.172</td>   <th>  Cond. No.          </th>  <td>4.86e+04</td>  
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large, 4.86e+04. This might indicate that there are<br/>strong multicollinearity or other numerical problems.



# Model Validation 


```python
from sklearn.model_selection import train_test_split

X = data.drop('price', axis=1).values
y = data['price'].values

X_train, X_Test, y_train, y_test = train_test_split(X,y, test_size=0.2, random_state=42) 
```


```python
var_name = ['X_train', 'X_Test','y_train', 'y_test']
var_list = [X_train, X_Test, y_train, y_test]
var_dict = dict(zip(var_name, var_list))

for name,var in var_dict.items():
    print(f"\nVariable: {name}")
    print(f"Data type: {type(var)}")
    print(f"Data Shape: {var.shape}")
```

    
    Variable: X_train
    Data type: <class 'numpy.ndarray'>
    Data Shape: (17227, 16)
    
    Variable: X_Test
    Data type: <class 'numpy.ndarray'>
    Data Shape: (4307, 16)
    
    Variable: y_train
    Data type: <class 'numpy.ndarray'>
    Data Shape: (17227,)
    
    Variable: y_test
    Data type: <class 'numpy.ndarray'>
    Data Shape: (4307,)



```python
from sklearn.linear_model import LinearRegression
linreg = LinearRegression()
linreg.fit(X_train, y_train)

y_hat_train = linreg.predict(X_train)
y_hat_test = linreg.predict(X_Test)
```


```python
from sklearn.metrics import mean_squared_error, r2_score

train_mse = mean_squared_error(y_train, y_hat_train)
train_r2 = r2_score(y_train, y_hat_train)

test_mse = mean_squared_error(y_test, y_hat_test)
test_r2 = r2_score(y_test, y_hat_test)

print ('Train Mean Squarred Error:', train_mse)
print ('Test Mean Squarred Error:', test_mse)
       
print('\nTrain R-Squared:', train_r2)
print('Test R-squared:', test_r2)
```

    Train Mean Squarred Error: 45592344919.44828
    Test Mean Squarred Error: 57595068843.52985
    
    Train R-Squared: 0.650592334846081
    Test R-squared: 0.6108097350133693


# K-Fold Validation 


```python
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import cross_val_score

cv_5_results = np.mean(cross_val_score(linreg, X, y, cv=5, scoring= 'neg_mean_squared_error'))
cv_10_results = np.mean(cross_val_score(linreg, X, y, cv=10, scoring= 'neg_mean_squared_error'))
cv_20_results = np.mean(cross_val_score(linreg, X, y, cv=20, scoring= 'neg_mean_squared_error'))

print('VC RESULTS')
print(f"Folds=5, score={cv_5_results}")
print(f"Folds=10, score={cv_10_results}")
print(f"Folds=20, score={cv_20_results}")
```

    VC RESULTS
    Folds=5, score=-48415599462.33136
    Folds=10, score=-48349144122.15642
    Folds=20, score=-48193086937.68425


# Conclusion: 
The variables used does not really reflect a high r squared or at least reach the threshold of .65  While I was able to go through my model, I believe that an improvement in cleaning up the data would result in a much better r squared.  I am eager to see what improvements I need to do to raise the r squared in my model.  

# How did you pick the question(s) that you did?

    The main goal for a business is to make money.  In this specific example, if a real estate company can leverage and successfully predict the prices of houses in the future (or at least come close), then they hold a competetive advantage of others and can quickly build up their business.  The main factor behind each of the methods I used for cleaning the data was making sure that there are no missing data (or at least fill them to the best of my knowledge), standardize their data so it will be consistent when putting them in our model, and dropping any data that won't contribute to our model. 
    
With the current model right now, I would probably need more time to examine the data before I recommend which variables can successfully predict house prices in the future in King County, Washington. 
   



```python

```
